package com.example.shchoolmate

data class Hour (
    var hour: Int,
    var up: Boolean?,
    var down: Boolean?,
    var title: String?
)

